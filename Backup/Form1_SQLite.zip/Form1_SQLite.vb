Imports Microsoft.Data.Sqlite
Imports System.IO

' ==============================================================
' === SQLite �֨��޲z�Ҳ� (by AntiGravity, 2026/04/06) ===
' �ت�: �N���s���� ConcurrentDictionary ���[�ƨ�ϺСA�קK���ҫ᭫�s�p��
' �޳N: �ϥ� Microsoft.Data.Sqlite �i�氪�ġB�󥭥x����Ʈw�ާ@
' ��s: 2026/04/06 - �N�έp�T��������W�ߪ� Dbg() �I�s�A�H�K�b ListView ����ܬ��h�Ӷ���
' ==============================================================
Partial Class Form1

    Private _dbPath As String = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "cache.db")

    ''' <summary>
    ''' ��l�Ƹ�Ʈw�A�Y���s�b�h�إ� cache.db �ëإ߸�ƪ�
    ''' </summary>
    Private Sub InitDatabase()
        Dim connectionString As String = "Data Source=" + _dbPath

        Try
            Using connection As New SqliteConnection(connectionString)
                connection.Open()

                Dim createTableSql As String = "
                    CREATE TABLE IF NOT EXISTS FolderCache (
                        FolderPath TEXT PRIMARY KEY,
                        MailCount INTEGER,
                        MailCountAll INTEGER,
                        FolderCount INTEGER,
                        FolderCountAll INTEGER,
                        FolderSize INTEGER,
                        FolderSizeAll INTEGER,
                        IsMailFolder INTEGER,
                        UpdateTime TEXT
                    );"

                Using command As New SqliteCommand(createTableSql, connection)
                    command.ExecuteNonQuery()
                End Using
            End Using
            Dbg("SQLite ��l�Ʀ��\", _dbPath)
        Catch ex As Exception
            Dbg("SQLite ��l�ƥ���", ex.Message)
        End Try
    End Sub

    ''' <summary>
    ''' �N�ثe���֨� Dictionary �X�֦s�J SQLite
    ''' </summary>
    Private Async Function SaveCachesToSQLiteAsync() As Task
        Dbg("�}�l�s�J SQLite", "�ǳƶi����[���x�s...")
        Dim sw As New Stopwatch() : sw.Start()

        Dim allKeys = _cacheMailCount.Keys.Union(_cacheMailCountAll.Keys).
                      Union(_cacheFolderCount.Keys).Union(_cacheFolderCountAll.Keys).
                      Union(_cacheFolderSize.Keys).Union(_cacheFolderSizeAll.Keys).
                      Union(_cacheIsMailFolder.Keys).Distinct().ToList()

        If allKeys.Count = 0 Then
            Dbg("�s�J����", "�֨����S��������") : Return
        End If

        Dim sMc, sMcA, sFc, sFcA, sSz, sSzA, sIsM As Integer

        Try
            Using connection As New SqliteConnection("Data Source=" + _dbPath)
                Await connection.OpenAsync()

                Using transaction = connection.BeginTransaction()
                    Dim upsertSql As String = "
                        INSERT OR REPLACE INTO FolderCache 
                        (FolderPath, MailCount, MailCountAll, FolderCount, FolderCountAll, FolderSize, FolderSizeAll, IsMailFolder, UpdateTime)
                        VALUES (@path, @mc, @mcAll, @fc, @fcAll, @fSize, @fSizeAll, @isMail, @time);"

                    Using command As New SqliteCommand(upsertSql, connection, transaction)
                        command.Parameters.Add("@path", SqliteType.Text)
                        command.Parameters.Add("@mc", SqliteType.Integer)
                        command.Parameters.Add("@mcAll", SqliteType.Integer)
                        command.Parameters.Add("@fc", SqliteType.Integer)
                        command.Parameters.Add("@fcAll", SqliteType.Integer)
                        command.Parameters.Add("@fSize", SqliteType.Integer)
                        command.Parameters.Add("@fSizeAll", SqliteType.Integer)
                        command.Parameters.Add("@isMail", SqliteType.Integer)
                        command.Parameters.Add("@time", SqliteType.Text)

                        Dim nowStr As String = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss")

                        For Each pathKey In allKeys
                            Dim mc, mcA, fc, fcA As Integer
                            Dim fSz, fSzA As Long
                            Dim isM As Boolean

                            Dim hMc = _cacheMailCount.TryGetValue(pathKey, mc) : If hMc Then sMc += 1
                            Dim hMcA = _cacheMailCountAll.TryGetValue(pathKey, mcA) : If hMcA Then sMcA += 1
                            Dim hFc = _cacheFolderCount.TryGetValue(pathKey, fc) : If hFc Then sFc += 1
                            Dim hFcA = _cacheFolderCountAll.TryGetValue(pathKey, fcA) : If hFcA Then sFcA += 1
                            Dim hSz = _cacheFolderSize.TryGetValue(pathKey, fSz) : If hSz Then sSz += 1
                            Dim hSzA = _cacheFolderSizeAll.TryGetValue(pathKey, fSzA) : If hSzA Then sSzA += 1
                            Dim hIsM = _cacheIsMailFolder.TryGetValue(pathKey, isM) : If hIsM Then sIsM += 1

                            command.Parameters("@path").Value = pathKey
                            command.Parameters("@mc").Value = If(Not hMc, -1, mc)
                            command.Parameters("@mcAll").Value = If(Not hMcA, -1, mcA)
                            command.Parameters("@fc").Value = If(Not hFc, -1, fc)
                            command.Parameters("@fcAll").Value = If(Not hFcA, -1, fcA)
                            command.Parameters("@fSize").Value = If(Not hSz, -1, fSz)
                            command.Parameters("@fSizeAll").Value = If(Not hSzA, -1, fSzA)
                            command.Parameters("@isMail").Value = If(Not hIsM, -1, If(isM, 1, 0))
                            command.Parameters("@time").Value = nowStr

                            Await command.ExecuteNonQueryAsync()
                        Next
                    End Using
                    transaction.Commit()
                End Using
            End Using
            sw.Stop()

            ' �N�έp�T��������h�� Dbg() �I�s�A�C�@�泣�|�b ListView ���ͦ��@�ӿW�߶���
            Dbg("�����s�J SQLite", "�`�B�z��Ƨ�����: " & allKeys.Count.ToString() & " (�Ӯ� " & sw.ElapsedMilliseconds.ToString() & "ms)")
            Dbg(" - [Save] �l���(�ۨ�/�l��)", sMc.ToString() & " / " & sMcA.ToString() & " ��")
            Dbg(" - [Save] �ؿ���(�ۨ�/�l��)", sFc.ToString() & " / " & sFcA.ToString() & " ��")
            Dbg(" - [Save] �j�p(�ۨ�/�l��)", sSz.ToString() & " / " & sSzA.ToString() & " ��")
            Dbg(" - [Save] �l�������аO", sIsM.ToString() & " ��")

            ProgressBar2.Text = "�֨��w�s�J��Ʈw (" & allKeys.Count.ToString() & " ��)�A�Ӯ� " & sw.ElapsedMilliseconds.ToString() & "ms"
        Catch ex As Exception
            Dbg("�s�J SQLite �o�Ͳ��`", ex.Message)
            ProgressBar2.Text = "�֨��s�J���ѡI�Ьd�� Debug Log"
        End Try
    End Function

    ''' <summary>
    ''' �q SQLite Ū���֨��ö�^ Dictionary
    ''' </summary>
    Private Async Function LoadCachesFromSQLiteAsync() As Task
        Dbg("�}�l�q SQLite Ū��", "�ǳƱq�ϺЫ�_�֨�...")
        Dim sw As New Stopwatch() : sw.Start()

        If Not File.Exists(_dbPath) Then
            Dbg("Ū������", "�䤣���Ʈw�ɮ�") : Return
        End If

        Dim totalRows, lMc, lMcA, lFc, lFcA, lSz, lSzA, lIsM As Integer

        Try
            Using connection As New SqliteConnection("Data Source=" + _dbPath)
                Await connection.OpenAsync()
                Await EnsureColumnsExist(connection)

                Dim selectSql As String = "SELECT * FROM FolderCache;"
                Using command As New SqliteCommand(selectSql, connection)
                    Using reader = Await command.ExecuteReaderAsync()
                        Dim iPth = reader.GetOrdinal("FolderPath")
                        Dim iMc = reader.GetOrdinal("MailCount")
                        Dim iMcA = reader.GetOrdinal("MailCountAll")
                        Dim iFc = reader.GetOrdinal("FolderCount")
                        Dim iFcA = reader.GetOrdinal("FolderCountAll")
                        Dim iSz = reader.GetOrdinal("FolderSize")
                        Dim iSzA = reader.GetOrdinal("FolderSizeAll")
                        Dim iIsM = reader.GetOrdinal("IsMailFolder")

                        While Await reader.ReadAsync()
                            totalRows += 1
                            Dim pathKey = reader.GetString(iPth)

                            Dim mc = reader.GetInt32(iMc) : If mc <> -1 Then _cacheMailCount(pathKey) = mc : lMc += 1
                            Dim mcA = reader.GetInt32(iMcA) : If mcA <> -1 Then _cacheMailCountAll(pathKey) = mcA : lMcA += 1
                            Dim fc = reader.GetInt32(iFc) : If fc <> -1 Then _cacheFolderCount(pathKey) = fc : lFc += 1
                            Dim fcA = reader.GetInt32(iFcA) : If fcA <> -1 Then _cacheFolderCountAll(pathKey) = fcA : lFcA += 1
                            Dim fSz = reader.GetInt64(iSz) : If fSz <> -1 Then _cacheFolderSize(pathKey) = fSz : lSz += 1
                            Dim fSzA = reader.GetInt64(iSzA) : If fSzA <> -1 Then _cacheFolderSizeAll(pathKey) = fSzA : lSzA += 1
                            Dim isM = reader.GetInt32(iIsM) : If isM <> -1 Then _cacheIsMailFolder(pathKey) = (isM = 1) : lIsM += 1
                        End While
                    End Using
                End Using
            End Using
            sw.Stop()

            ' Ū�^�T���]������h�ӿW�߶���
            Dbg("�����q SQLite Ū��", "�`���J��Ƨ�����: " & totalRows.ToString() & " (�Ӯ� " & sw.ElapsedMilliseconds.ToString() & "ms)")
            Dbg(" - [Load] �l���(�ۨ�/�l��)", lMc.ToString() & " / " & lMcA.ToString() & " ��")
            Dbg(" - [Load] �ؿ���(�ۨ�/�l��)", lFc.ToString() & " / " & lFcA.ToString() & " ��")
            Dbg(" - [Load] �j�p(�ۨ�/�l��)", lSz.ToString() & " / " & lSzA.ToString() & " ��")
            Dbg(" - [Load] �l�������аO", lIsM.ToString() & " ��")

            ProgressBar2.Text = "�w�q��Ʈw��_ " & totalRows.ToString() & " ���֨��A�Ӯ� " & sw.ElapsedMilliseconds.ToString() & "ms"
        Catch ex As Exception
            Dbg("Ū�� SQLite �o�Ͳ��`", ex.Message)
            ProgressBar2.Text = "�֨�Ū�����ѡI�Ьd�� Debug Log"
        End Try
    End Function

    ''' <summary>
    ''' ���U��ơG�T�O��ƪ����c�]�t�̷s��� (�ɯ��ª���Ʈw)
    ''' </summary>
    Private Async Function EnsureColumnsExist(conn As SqliteConnection) As Task
        Dim columnsToAdd As New List(Of String) From {"FolderSize", "FolderSizeAll", "IsMailFolder"}
        For Each col In columnsToAdd
            Dim checkSql = "PRAGMA table_info(FolderCache);"
            Dim exists = False
            Using cmd = New SqliteCommand(checkSql, conn)
                Using r = Await cmd.ExecuteReaderAsync()
                    While Await r.ReadAsync()
                        If r.GetString(1).Equals(col, StringComparison.OrdinalIgnoreCase) Then
                            exists = True : Exit While
                        End If
                    End While
                End Using
            End Using
            If Not exists Then
                Dbg("�ɯŸ�Ʈw", "�s�W���: " + col)
                Using alterCmd = New SqliteCommand("ALTER TABLE FolderCache ADD COLUMN " + col + " INTEGER DEFAULT -1;", conn)
                    Await alterCmd.ExecuteNonQueryAsync()
                End Using
            End If
        Next
    End Function

End Class